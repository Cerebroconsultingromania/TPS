# Export conversatii Tennis Performance System
Cursor nu muta chat-ul intre conturi. Deschide aceste fisiere pe noul cont.
- `markdown/091285df-3bad-41dc-8d4e-290a82022aaa.md` — 190 mesaje, 83 KB

Vezi `CITESTE-MA.md` pentru pasi.
