# Conversatie curenta — mutare pe alt cont Cursor

## Intrebare
Mutarea intregului proiect de website tenis (conversatie) pe alt cont Cursor.
GitHub si Vercel sunt deja pe bogdancerebro@gmail.com.

## Raspuns important
- Chat-ul Cursor NU se importa ca thread in noul cont.
- Proiectul DA: deschizi folderul sau clonezi GitHub in noul Cursor.
- Conversatiile sunt exportate ca fisiere Markdown + JSONL in `conversation-export/`.

## Ce sa faci pe noul cont
1. Cursor (cont nou) → Open Folder → `~/Desktop/tennis-performance-system`
   sau clone din GitHub daca ai deja repo-ul.
2. In chatul nou, ataseaza `conversation-export/markdown/` sau scrie:
   "Citeste conversation-export/CITESTE-MA.md si continua de acolo."
3. Vercel nu trebuie redeployat ca sa ramana live.

## Local
- Site: http://127.0.0.1:3006
- Admin: http://127.0.0.1:3006/admin
- Start: `npm run site`
