# Export conversatie — Tennis Performance Development System

Cursor **nu** poate muta istoricul de chat dintr-un cont in altul.
Acest folder pastreaza transcript-urile JSONL din aceasta masina.

## Unde sunt fisierele
In proiect: `conversation-export/`
- `CONVERSATIE.md` — acest ghid
- `raw/` — fisiere `.jsonl` (log-ul brut al conversatiilor)

## Cum le folosesti pe noul cont Cursor
1. Cloneaza repo-ul GitHub.
2. Deschide folderul in Cursor (contul nou).
3. Chat-ul vechi nu apare automat. Poti atasa/incarca `conversation-export/raw/*.jsonl` sau acest markdown ca context.
4. Pentru continuitate, deschide si `TRANSFER.md` din radacina proiectului.

## Ce s-a construit in conversatii (rezumat)
- Site Next.js (port local 3006): `npm run site`
- Admin media + analitice: `/admin` (parola din `ADMIN_PASSWORD` sau default in cod)
- Imagini teren albastru + star junior + video-uri in `public/`
- Vercel production trebuie lasat activ; reconectarea Git se face dupa ce repo-ul e pe GitHub

## Limitare
Chat-ul din Cursor nu este un export oficial „Share conversation” catre alt cont.
JSONL-urile de aici sunt backup-ul cel mai complet disponibil local.
