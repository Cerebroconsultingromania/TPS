# Cum muti proiectul + conversatia pe noul Cursor

## Ce NU se poate
Cursor nu transfera istoricul de chat dintr-un cont in altul.
Nu exista „import conversation” oficial.

## Ce DA se poate (fisiere)
Tot ce e important e in acest folder:

| Fisier | Rol |
|---|---|
| `CITESTE-MA.md` | acest ghid |
| `markdown/*.md` | conversatiile, lizibile |
| `raw/*.jsonl` | backup brut Cursor |

## Pe noul cont Cursor
1. File → Open Folder → `tennis-performance-system`
2. Chat nou: ataseaza `conversation-export/markdown/` (sau scrie sa citeasca `CITESTE-MA.md`)
3. `npm install` apoi `npm run site` daca lucrezi local

## Proiectul
Codul e pe disc: `~/Desktop/tennis-performance-system`
Daca GitHub e deja pe noul cont, cloneaza repo-ul acolo — Vercel ramane live.

## Atentie
Markdown-ul poate contine parole mentionate in chat. Nu-l face public.
